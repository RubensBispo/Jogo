
package Model;

import java.util.Random;
import javax.swing.JOptionPane;


public class jogoDao {
    public static String total ="";
    public static Random ale = new Random();
    public static int c=0;
    public static long [] valor = new long[15];
    
    
    public static void numero(){
        
    }
    
    public static void advinha(){
        
        for(c =0 ; c< 5; c++){
           valor[c] = ale.nextInt(+15)-(-1);
           total = total + valor[c] + " | ";
        }
      
        JOptionPane.showMessageDialog(null, total);
    } 
    
    
}
