
package main;

import View.Menu_GUI;


public class Main {

 
    public static void main(String[] args) {
        Menu_GUI.menu();
    }
    
}
