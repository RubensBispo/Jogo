
package View;

import javax.swing.JOptionPane;


public class Menu_GUI {
    public static int op = 0;
   public static String x = "";
   
   
    public static void menu(){
       while(op != 5){
          
           x = JOptionPane.showInputDialog(null,"1-Digite um numero maior que zero\n\n n0-Sair");
           op = Integer.parseInt(x);
          
           if(op ==0){
               JOptionPane.showMessageDialog(null, "Até mais...");
             
           }else if(op ==1){
               Model.jogoDao.numero();
           }else if(op ==3){
              
           }else if(op ==4){
               
           }else if(op ==5){
               
           }else{
               JOptionPane.showMessageDialog(null, "Opção Inválida");
           }
          
       }
       
       
    }
}
